# Cloud-Based Workforce Shift Scheduling System

A full-stack academic project using Python Flask, SQLite, HTML and CSS.

## Features
- Admin and employee login with hashed passwords
- Admin dashboard with employee, shift and pending-request counts
- Create employee accounts
- Create and delete employee shifts
- Employee dashboard to view personal shifts
- Employees submit shift change requests
- Admin approves or rejects requests
- JSON API endpoint: `GET /api/shifts`

## Run locally (Windows / VS Code)
Install Python 3.10+.

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Demo credentials
- Admin: `admin` / `Admin123!`
- Employee: `employee1` / `Employee123!`

Change demo passwords and set a strong `SECRET_KEY` before deployment. Existing demo accounts are created only on the first database initialisation; changing environment variables later does not automatically reset their passwords.

## Project structure
```text
cloud_workforce_shift_scheduling/
├── app.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── workforce.db       # created automatically
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── admin.html
│   ├── employee.html
│   └── employees.html
└── static/
    └── style.css
```

## API
`GET /api/shifts` returns the signed-in user's shifts as JSON. Admin users receive all shifts; employees receive only their own.

## Notes
This is a classroom-ready local prototype. The app is not hosted in the cloud yet. Cloud deployment requires a hosting provider, HTTPS, production WSGI server, managed database, backups, CSRF protection, access monitoring, and secure secret management. Shift time validation currently supports same-day shifts only (end time must be later than start time).
