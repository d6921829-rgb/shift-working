import os, sqlite3
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, "workforce.db")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-before-deployment")

def connect():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with connect() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL, full_name TEXT NOT NULL, role TEXT NOT NULL,
            department TEXT DEFAULT '')""")
        c.execute("""CREATE TABLE IF NOT EXISTS shifts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL,
            shift_date TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL,
            department TEXT NOT NULL, notes TEXT DEFAULT '',
            status TEXT DEFAULT 'Scheduled',
            FOREIGN KEY(employee_id) REFERENCES users(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS swap_requests(
            id INTEGER PRIMARY KEY AUTOINCREMENT, shift_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL, requested_date TEXT NOT NULL,
            reason TEXT DEFAULT '', status TEXT DEFAULT 'Pending',
            FOREIGN KEY(shift_id) REFERENCES shifts(id),
            FOREIGN KEY(employee_id) REFERENCES users(id))""")
        if not c.execute("SELECT id FROM users WHERE username='admin'").fetchone():
            c.execute("INSERT INTO users(username,password,full_name,role,department) VALUES(?,?,?,?,?)",
                      ("admin", generate_password_hash(os.environ.get("ADMIN_PASSWORD","Admin123!")),
                       "System Administrator","admin","Administration"))
        if not c.execute("SELECT id FROM users WHERE username='employee1'").fetchone():
            c.execute("INSERT INTO users(username,password,full_name,role,department) VALUES(?,?,?,?,?)",
                      ("employee1", generate_password_hash("Employee123!"), "Demo Employee","employee","Operations"))

def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if session.get("role") != "admin":
            flash("Administrator access required.", "danger")
            return redirect(url_for("dashboard"))
        return fn(*a, **kw)
    return wrapper

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        with connect() as c:
            u = c.execute("SELECT * FROM users WHERE username=?", (request.form.get("username","").strip(),)).fetchone()
        if u and check_password_hash(u["password"], request.form.get("password","")):
            session.update(user_id=u["id"], username=u["username"], full_name=u["full_name"], role=u["role"])
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    with connect() as c:
        if session["role"] == "admin":
            shifts = c.execute("""SELECT s.*,u.full_name FROM shifts s JOIN users u ON u.id=s.employee_id
                                ORDER BY s.shift_date,s.start_time""").fetchall()
            employees = c.execute("SELECT id,full_name,department FROM users WHERE role='employee' ORDER BY full_name").fetchall()
            pending = c.execute("""SELECT r.*,u.full_name,s.shift_date,s.start_time,s.end_time
                                  FROM swap_requests r JOIN users u ON u.id=r.employee_id
                                  JOIN shifts s ON s.id=r.shift_id WHERE r.status='Pending' ORDER BY r.id DESC""").fetchall()
            stats = {
                "employees": c.execute("SELECT COUNT(*) n FROM users WHERE role='employee'").fetchone()["n"],
                "shifts": c.execute("SELECT COUNT(*) n FROM shifts").fetchone()["n"],
                "pending": len(pending)
            }
            return render_template("admin.html", shifts=shifts, employees=employees, pending=pending, stats=stats)
        shifts = c.execute("SELECT * FROM shifts WHERE employee_id=? ORDER BY shift_date,start_time",
                           (session["user_id"],)).fetchall()
        requests = c.execute("""SELECT r.*,s.shift_date,s.start_time,s.end_time FROM swap_requests r
                               JOIN shifts s ON s.id=r.shift_id WHERE r.employee_id=? ORDER BY r.id DESC""",
                             (session["user_id"],)).fetchall()
    return render_template("employee.html", shifts=shifts, requests=requests)

@app.route("/employees", methods=["GET","POST"])
@login_required
@admin_required
def employees():
    if request.method == "POST":
        name=request.form.get("full_name","").strip()
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        dept=request.form.get("department","").strip()
        if not all([name,username,password,dept]):
            flash("Please complete all employee fields.", "danger")
        else:
            try:
                with connect() as c:
                    c.execute("INSERT INTO users(username,password,full_name,role,department) VALUES(?,?,?,?,?)",
                              (username,generate_password_hash(password),name,"employee",dept))
                flash("Employee account created.", "success")
            except sqlite3.IntegrityError:
                flash("That username already exists.", "danger")
        return redirect(url_for("employees"))
    with connect() as c:
        people=c.execute("SELECT id,full_name,username,department FROM users WHERE role='employee' ORDER BY full_name").fetchall()
    return render_template("employees.html", employees=people)

@app.route("/shifts/create", methods=["POST"])
@login_required
@admin_required
def create_shift():
    employee=request.form.get("employee_id")
    date=request.form.get("shift_date")
    start=request.form.get("start_time")
    end=request.form.get("end_time")
    dept=request.form.get("department","").strip()
    notes=request.form.get("notes","").strip()
    if not all([employee,date,start,end,dept]) or start >= end:
        flash("Enter valid shift details. End time must be later than start time.", "danger")
    else:
        with connect() as c:
            c.execute("INSERT INTO shifts(employee_id,shift_date,start_time,end_time,department,notes) VALUES(?,?,?,?,?,?)",
                      (employee,date,start,end,dept,notes))
        flash("Shift scheduled successfully.", "success")
    return redirect(url_for("dashboard"))

@app.route("/shifts/<int:shift_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_shift(shift_id):
    with connect() as c:
        c.execute("DELETE FROM swap_requests WHERE shift_id=?", (shift_id,))
        c.execute("DELETE FROM shifts WHERE id=?", (shift_id,))
    flash("Shift removed.", "success")
    return redirect(url_for("dashboard"))

@app.route("/swap-request", methods=["POST"])
@login_required
def swap_request():
    if session["role"] != "employee":
        return redirect(url_for("dashboard"))
    shift_id=request.form.get("shift_id")
    date=request.form.get("requested_date")
    reason=request.form.get("reason","").strip()
    with connect() as c:
        shift=c.execute("SELECT id FROM shifts WHERE id=? AND employee_id=?",
                        (shift_id,session["user_id"])).fetchone()
        if not shift or not date:
            flash("Select one of your shifts and a requested date.", "danger")
        else:
            c.execute("INSERT INTO swap_requests(shift_id,employee_id,requested_date,reason) VALUES(?,?,?,?)",
                      (shift_id,session["user_id"],date,reason))
            flash("Shift change request submitted for approval.", "success")
    return redirect(url_for("dashboard"))

@app.route("/swap/<int:req_id>/<decision>", methods=["POST"])
@login_required
@admin_required
def decide_swap(req_id, decision):
    if decision not in ("Approved","Rejected"):
        return redirect(url_for("dashboard"))
    with connect() as c:
        c.execute("UPDATE swap_requests SET status=? WHERE id=? AND status='Pending'",(decision,req_id))
    flash(f"Request {decision.lower()}.", "success")
    return redirect(url_for("dashboard"))

@app.route("/api/shifts")
@login_required
def api_shifts():
    with connect() as c:
        if session["role"] == "admin":
            rows=c.execute("""SELECT s.id,s.shift_date,s.start_time,s.end_time,s.department,s.status,u.full_name
                              FROM shifts s JOIN users u ON u.id=s.employee_id ORDER BY s.shift_date""").fetchall()
        else:
            rows=c.execute("""SELECT id,shift_date,start_time,end_time,department,status
                              FROM shifts WHERE employee_id=? ORDER BY shift_date""",(session["user_id"],)).fetchall()
    return jsonify([dict(r) for r in rows])

init_db()
if __name__ == "__main__":
    app.run(debug=True)
